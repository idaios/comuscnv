library(foreach)
library(doMC)
registerDoMC(6)  #change the 2 to your number of CPU cores  

comusDir <- "./comus/"


a <- as.numeric(read.table("prop_model.list"))
propratio <- (1:9)*0.1
curdir <- getwd()
foreach(x=1:length(a)) %dopar% { 
    i <- a[x]
    system(paste("mkdir model", i, "_prop", sep=""))
    setwd(paste("model", i, "_prop", sep=""))
    dir2 <- getwd()
    for(j in propratio){
        system(paste("mkdir prop", j, sep=""))
        setwd(paste("prop", j, sep=""))
        system(paste("cp ", curdir, "/hg38.100way.scientificNames.ONELINE.nh .", sep=""))
        system(paste("cp ", curdir, "/tree_analysis2.R .", sep=""))
        cmd <- paste(curdir, "/", comusDir, "comus4 100 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3  1000 -t ", 0.0025*i, " -iphylo hg38.100way.scientificNames.ONELINE.nh -name ", i, ".inf -oCoalescent -oPhylo -msites ", i, " -MUTCOPYMODEL 3 ", j, sep="")
        cmd2 <- paste("mv mutationTimes.txt mutationTimes.", i, ".txt",sep="")
        cmd2.1 <- paste("cp ", curdir, "/clean_dataset.sh .", sep="")
        cmd2.2 <- paste("cp ", curdir, "/CN_Species_Raw.csv .", sep="")
        cmd2.3 <- paste("cp ", curdir, "/Data_Pavlos.txt .", sep="")
        cmd3 <- paste("Rscript ./tree_analysis2.R comus_Microsat.", i, ".inf", sep="")
        
        system(cmd)
        system(cmd2)
        system(cmd2.1)
        system(cmd2.2)
        system(cmd2.3)
        system(cmd3)
        write.table(file="run.sh", x=c(cmd, cmd2, cmd2.1, cmd2.2, cmd2.3, cmd3), quote=F, row.names=F, col.names=F)
        setwd(dir2)
    }
    setwd(curdir)
}
