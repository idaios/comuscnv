## COMUS v4 ##
## This is the version of CoMuS for the evolution of copy number variants. 


## LOG

## 17/5/1980
## copy number variants implementation using a pre-order tree traversal

## 8/2/2017
## Add option to
## -- track migration events and
## -- microsatelites / repeats evolution


########### COMPILE ########
##To compile comus you can type

make

## To compile CoMuStats:
cd CoMuStats2
make

# comuscnv
