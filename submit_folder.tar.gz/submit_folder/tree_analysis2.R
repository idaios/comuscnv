rm(list=ls())
## load the necessary libraries
getwd()
library(ape)
require(Deducer)

## for plotting
library(easyGgplot2)

## for parallel running of for loops
library(foreach)
library(doMC)
registerDoMC(20)

## default input files
observed <- read.table("Data_Pavlos.txt", header=TRUE)
input.file <- "comus_Microsat.500.inf"

## read arguments from command line. If nothing is given, then use defaults
args = commandArgs(trailingOnly=TRUE)
if( length(args) > 0){
    input.file <- args[1]
}

## just extract the mutation rate parameter from the file name
mutation.param <- gsub(x=input.file, replacement='\\1', pattern='comus_Microsat.(.+).inf', perl=TRUE)

## get the input phylogenetic tree
tree <- read.tree("hg38.100way.scientificNames.ONELINE.nh")

## IMPORTANT: DISTANCES between species based on the tree
a <- cophenetic(tree)
## number of species in the tree
nspecies <- nrow(a)

## this command will "clean" the input file from the ms-like headers
## the clean file will only contain the copy numbers for all individuals ( = 100x3)
system(paste("./clean_dataset.sh ", input.file, sep=""))

## get the clean file name
pure.file.name <- sub(pattern = "(.*)\\..*$", replacement = "\\1", basename(input.file))
clean.file <- paste(pure.file.name, ".CLEAN", sep="")

## get the simulated data
sim.raw <- read.table(clean.file)


## This function is used to calculate
## the distance between the means of two vectors.
## It will be used to get the difference between the means
## of the copy numbers between 2 species
dist.fun <- function(a,b){
    ##b.prime <- perm(as.numeric(b), TRUE)
    #print(b.prime)
    d <- abs(mean(a) - mean(b)) ##apply(b, 1, function(x){sum(abs(a-x))})
    return(d)
    #print(d)
    ##mean.d <- mean(d)
    ##return(mean.d)
}

## This function will give the distance between
## two species. The indexes correspond to the
## individuals of each species which is given by
## x.ind and y.ind
## k is the number of individuals per species (here 3, that's why it's the default)
sp.dist <- function(xy.vec,k=3,vec){
    x <- xy.vec[1]
    y <- xy.vec[2]
    x.ind <- ((x-1)*k+1):(x*k)
    y.ind <- ((y-1)*k+1):(y*k)
    distance <- dist.fun(vec[x.ind], vec[y.ind])
    return(distance)
}

## this matrix provides all C(100,2) combinations
## i.e. (1,2), (1,3), ..., (99,100)
## it will be used to get all pairwise distances between all 100 species of the
## phylogenetic tree
comb.matrix <- combn(nspecies, 2)

## a parallel loop to get distances between all species
xx <- foreach(i=1:nrow(sim.raw)) %dopar% {
    if( i %% 100 == 0)
        print(i)
    ## for each species combination, apply the sp.dist function which
    ## returns the distance between the means from two species
    apply(comb.matrix,2, sp.dist, k=3, as.numeric(sim.raw[i,]))
}

## all distances. The rows will be the distances between all combinations of species
## Data are getting into the matrix by row
distances.all <- matrix(unlist(xx), nrow=nrow(sim.raw), ncol=ncol(comb.matrix), byrow=T)

## just the phylogenetic distance between two species
## i do that to guarantee that the order between the differences in the copy number of the
## phylogenetic distance is the same
get.phylo.dist <- function(xy.vec, dist.mat){
    return(dist.mat[xy.vec[1], xy.vec[2]])
}

## traverse the distance matrix
sim.dists <- t(distances.all)
## phylogenetic distances
phylo.dist <- apply(comb.matrix,2, get.phylo.dist, a)
## indexes of the two species
sp1.index <- comb.matrix[1,]
sp2.index <- comb.matrix[2,]
## names of the species
sp1 <- row.names(a)[sp1.index]
sp2 <- row.names(a)[sp2.index]

## the final matrix containing all data
final.matrix <- data.frame(sp1.index=sp1.index,
                           sp2.index=sp2.index,
                           sp1=sp1,
                           sp2=sp2,
                           phylo.dist=phylo.dist,
                           av.dists=apply(sim.dists, 1, mean),
                           sim.dists=sim.dists
                           )

write.table(x=final.matrix, file=paste(pure.file.name, ".MATRIX.OUT", sep=""), quote=F, sep="\t", col.names=TRUE)


## Here I plot the data.
## In total there are 1000 x 4950 points. These are too many
## Thus instead of 1000, I use 5 points per species pair
## NOTE: only for plotting. For the real analysis, I use all points
M <- 5
x <- rep(final.matrix$phylo.dist, each=M)
y <- as.numeric(apply(sim.dists, 1, sample, size=M, replace=F))

## plot the data. With yellow color, I plot the mean of all simulated points for a given pair
pdf(paste(pure.file.name, ".PDF", sep=""))
plot(x, y, xlab="Phylogenetic distance", ylab="Differences", pch=16, ylim=c(0, max(c(observed[,4], y) )), cex=0.5, xlim=c(0, max(observed[,3]*1.2)), main=paste("mutation rate: ", mutation.param ))
points(final.matrix$phylo.dist, final.matrix$av.dists, col='yellow')
lw1 <- loess(final.matrix$av.dists~final.matrix$phylo.dist, degree=2)
j <- order(lw1$x)
points(lw1$x[j], lw1$fitted[j], col="red", lwd=3, type='l')
points(observed[,3], observed[,4], col="blue", pch=19, cex=1.)
dev.off()


## P-value procedure ###

## This is the main function for the following process to calculate p-values
## 1. find which species are in 'more or less the same phylogenetic distance' with a given observed point
##    'more or less' means that I allow for some tolerance (tol)
## 2. Get a random species comparison (line) that fulfills 1.
## 3. From the line of 2. get a random point. This is a random point from the null distribution
## 4. Calculate the distance of this random point from the mean value of the given phylogenetic distance
## 5. repeat steps 1-4 for all phylogenetic distances
## 6. then get the mean distance from all phylogenetic distances
## 7. repeat steps 1-6 for 1,000 times (this is done outside the function)
## IMPORTANT: This is a less conservative method for the calculation of the p-value,
## because in reality the data can come only from one instance and not from multiple (here it's allowed to mix data from different simulations
getSampling <- function(observed.dist, observed.copies, tol)
{
    obs.distance.mean <- c()
    sampled.dists <- c()
    k <- c(1:length(observed.dist))
    for(i in k){
        ## the tolerance
        rel.indexes <- which((final.matrix$phylo.dist >= (observed.dist[i] - observed.dist[i]*tol))
                             &
                             (final.matrix$phylo.dist <= (observed.dist[i] + observed.dist[i]*tol)) )
        ## if there are no points fullfill the criteria, do nothing!
        if( length(rel.indexes) == 0){ print(0) }
        else{
            mean.point <- mean(sim.dists[rel.indexes,]) 
            asample.1 <- sample(x=rel.indexes, size=1)
            asample.2 <- sample(x=sim.dists[asample.1,], size=1)
            sampled.dists <- c(sampled.dists, abs(mean.point - asample.2))
            obs.distance.mean <- c(obs.distance.mean, abs(mean.point - observed.copies[i]) )
        }
    }
    return(list(sampled.dists, obs.distance.mean))
}


## the difference to the previous function, is that I force
## here to get data only from one simulations. I think that this
## is more fair, but perhaps I'll have to ask somebody for confirmation
getSampling2 <- function(observed.dist, observed.copies, tol, ii)
{
    obs.distance.mean <- c()
    sampled.dists <- c()
    k <- c(1:length(observed.dist))
    for(i in k){
        ## the tolerance
        rel.indexes <- which((final.matrix$phylo.dist >= (observed.dist[i] - observed.dist[i]*tol))
                             &
                             (final.matrix$phylo.dist <= (observed.dist[i] + observed.dist[i]*tol)) )
        ## if there are no points fullfill the criteria, do nothing!
        if( length(rel.indexes) == 0){ print(0) }
        else{
            mean.point <- mean(sim.dists[rel.indexes,]) 
            asample.1 <- sample(x=rel.indexes, size=1)
            ## here get data only from a given simulation
            asample.2 <- sim.dists[asample.1,ii] 
            sampled.dists <- c(sampled.dists, abs(mean.point - asample.2))
            obs.distance.mean <- c(obs.distance.mean, abs(mean.point - observed.copies[i]) )
        }
    }
    return(list(sampled.dists, obs.distance.mean))
}


getSampling3 <- function(observed.dist, observed.copies, tol, ii)
{
    obs.distance.mean <- c()
    sampled.dists <- c()
    k <- c(1:length(observed.dist))
    for(i in k){
        ## the tolerance
        rel.indexes <- which((final.matrix$phylo.dist >= (observed.dist[i] - observed.dist[i]*tol))
                             &
                             (final.matrix$phylo.dist <= (observed.dist[i] + observed.dist[i]*tol)) )
        ## if there are no points fullfill the criteria, do nothing!
        if( length(rel.indexes) == 0){ print(0) }
        else{
            mean.point <- mean(sim.dists[rel.indexes,]) 
            asample.1 <- sample(x=rel.indexes, size=1)
            ## here get data only from a given simulation
            asample.2 <- sim.dists[asample.1,ii] 
            sampled.dists <- c(sampled.dists, abs(mean.point - asample.2))
            obs.distance.mean <- c(obs.distance.mean, abs(mean.point - observed.copies[i]) )
        }
    }
    return(list(sampled.dists, obs.distance.mean))
}



## p-value calculation 1
Nsampling <- 1000
sampled.mean.distances <- foreach(i=1:Nsampling) %dopar% {
    dd <- getSampling(observed[,3], observed[,4], 0.01)
    c(mean(dd[[1]]), mean(dd[[2]]) )
}
dist.mat.sim.obs <- matrix(unlist(sampled.mean.distances), ncol=2, byrow=TRUE)
obs.mean.dist <- mean(dist.mat.sim.obs[,2])
## get the p-value as the number of simulated points with greater distance (to the mean) than observed
pvalue <- length(which(dist.mat.sim.obs[,1] >= obs.mean.dist))/length(dist.mat.sim.obs[,1])

if(pvalue == 0){
    pvalue <- " < 0.001"
}

## plot the null distribution and the observation
pdf(paste("comus_Microsat.", mutation.param, ".distr.PDF", sep=""))
plot(density(dist.mat.sim.obs[,1]), xlim=c(0, max(c(dist.mat.sim.obs[,1], obs.mean.dist) ) ), main=paste("Mutation param: ", mutation.param, "\n", "p-value: ", pvalue, "\nobserved: ", obs.mean.dist))
abline(v=obs.mean.dist, col="red", type='l')
dev.off()


## p-value calculation 2
Nsampling <- 1000
sampled.mean.distances <- foreach(i=1:Nsampling) %dopar% {
    dd <- getSampling2(observed[,3], observed[,4], 0.01, i)
    c(mean(dd[[1]]), mean(dd[[2]]) )
}
dist.mat.sim.obs <- matrix(unlist(sampled.mean.distances), ncol=2, byrow=TRUE)
obs.mean.dist <- mean(dist.mat.sim.obs[,2])
## get the p-value as the number of simulated points with greater distance (to the mean) than observed
pvalue <- length(which(dist.mat.sim.obs[,1] >= obs.mean.dist))/length(dist.mat.sim.obs[,1])

if(pvalue == 0){
    pvalue <- " < 0.001"
}

## plot the null distribution and the observation
pdf(paste("comus_Microsat.", mutation.param, ".distr2.PDF", sep=""))
plot(density(dist.mat.sim.obs[,1]), xlim=c(0, max(c(dist.mat.sim.obs[,1], obs.mean.dist) ) ), main=paste("Mutation param: ", mutation.param, "\n", "p-value: ", pvalue, "\nobserved: ", obs.mean.dist))
abline(v=obs.mean.dist, col="red", type='l')
dev.off()

#############################################################
## p-value calculation 3 (per phylogenetic distance level) ##
Nsampling <- 1000
sampled.mean.distances <- foreach(i=1:Nsampling) %dopar% {
    dd <- getSampling3(observed[,3], observed[,4], 0.01, i)
}

## get observations
## it's the same idea as before but now I don't average all distances from the phylogenetic
## levels. Instead I print out a pvalue per phylogenetic level

## the observed distances from the mean
tt <- sapply(1:Nsampling, function(x){
    (sampled.mean.distances[[x]][[2]])
})

## the simulated distances from the mean
tt.sim <- sapply(1:Nsampling, function(x){
    (sampled.mean.distances[[x]][[1]])
})

## I just need one observed distance, thus just the first column is enough
## in any case other columns contain exactly the same value
observed.mean.dd <- tt[,1]

## empirical pvalues: which sim distance is greater than the observed
d.pvalues <- sapply(1:dim(tt.sim)[1], function(x){
    sum(tt.sim[x,] >= observed.mean.dd[x])/length(tt.sim[x,] >= observed.mean.dd[x])
})


## plot the resuls
thres <- 0.05
pdf(paste("comus_Microsat.", mutation.param, ".outlierpvalues.PDF", sep=""), width=15, height=10)
par(mar=c(4.1, 4.1, 4.1, 35), xpd=TRUE)
plot(d.pvalues, observed[,3], ylim=c(0, max(observed[,3]*1.5)), xlab="p-value", ylab="Phylogenetic distance", axes=F)
axis(side=1, pos=0)
axis(side=2, pos=0)
points(c(thres,thres), c(0, max(observed[,3]*1.5)), col='red', type='l')
outl <- which(d.pvalues < thres)
points(d.pvalues[outl], observed[outl,3], col=1:length(outl), pch=16)
leg <- data.frame(observed[outl,1], observed[outl,2], observed[outl,3], d.pvalues[outl])
allleg <- data.frame(observed[,1], observed[,2], observed[,3], d.pvalues)
legend.out <- apply(leg, 1, paste, collapse=":")
legend("topright", legend=c(legend.out, paste("threshold:", thres)), col=c(1:length(outl), "red"), pch=c(rep(16, length(outl)), NA), lty=c(rep(0, length(outl)),1), inset=c(-.85,0))
dev.off()

## write results into a file
colnames(leg) <- c("species1", "species2", "phylogeneticDistance",  "pvalue")
colnames(allleg) <- c("species1", "species2", "phylogeneticDistance",  "pvalue")
write.table(x=allleg, file=paste("comus_Microsat.", mutation.param, ".outlierpvalues.txt", sep=""), sep="\t", quote=F, row.names=F, col.names=TRUE)


#### within species
within.sp <- function(x, vec, k=3){
    x.ind <- ((x-1)*k+1):(x*k)
    div <- var(vec[x.ind])
    return(div)
}

within.sp.var <- function(x, vec, k=3){
    x.ind <- ((x-1)*k+1):(x*k)
    div <- mean(c(dist(vec[x.ind])))
    ##m <- mean(vec[x.ind])
    return(div)
}

within.sp.mean <- function(x, vec, k=3){
    x.ind <- ((x-1)*k+1):(x*k)
    ##div <- var(vec[x.ind])
    m <- mean(vec[x.ind])
    return(m)
}

ws.mean <- foreach(i=1:nrow(sim.raw)) %dopar% {
    sapply(1:nrow(a), within.sp.mean, as.numeric(sim.raw[i,]), 3)
}

ws.var <- foreach(i=1:nrow(sim.raw)) %dopar% {
    sapply(1:nrow(a), within.sp.var, as.numeric(sim.raw[i,]), 3)
}

within.species.var.mat <- matrix(unlist(ws.var), ncol=nrow(a), byrow=TRUE)

write.table(within.species.var.mat, file=paste("comus_Microsat.", mutation.param, ".withinspeciesvariancematrix.txt", sep=""), sep="\t", quote=F, row.names=F, col.names=F)


pdf(file=paste("comus_Microsat.", mutation.param, ".withinspeciesvariancematrix.HSAP.PDF", sep=""))
hist(within.species.var.mat[,1], breaks=20)
dev.off()


##observed within species
ows <- read.table("CN_Species_Raw.csv", sep=',', h=TRUE)
names(ows)

pdf("boxplot_species_estCounts.pdf")
ggplot2.boxplot(data=ows, xName="Species", yName="Diploid_EST")
dev.off()

require(dplyr)
##owsvec %>% group_by(Species) %>% summarise(Diploid_EST)
owsvec <- aggregate(Diploid_EST~Species, ows, as.numeric)
owsvec.mean <- aggregate(Diploid_EST~Species, ows, mean)
owsvec.var <- aggregate(Diploid_EST~Species, ows, function(x){ mean(c(dist(x))) } )


intersections <- c()
slopes <- c()

pdf(paste("comus_Microsat.", mutation.param, ".meanvar.pdf", sep=""), height=5, width=10)
##layout(matrix(1:2, byrow=TRUE, nrow=1))
plot(owsvec.mean[,2], owsvec.var[,2], pch=19, xlim=c(0, max(c(owsvec.mean[,2], unlist(ws.mean) ))), ylim=c(0, max(c(owsvec.var[,2], unlist(ws.var) ), na.rm=TRUE)) )
points(unlist(ws.mean), unlist(ws.var), pch=1, col="lightgray", cex=0.3)
for(i in 1:length(ws.var)){
    linmod <- lm(unlist(ws.var[[i]]) ~ unlist(ws.mean[[i]]))
    intersections <- c(intersections, linmod$coefficients[1])
    slopes <- c(slopes, linmod$coefficients[2])
    if(sum(is.na(linmod$coefficients)) == 0 )
        abline(linmod, col='lightblue')
}
linmod <- lm(owsvec.var[,2]~owsvec.mean[,2])
abline(linmod, col='black', lw=2)
points(owsvec.mean[,2], owsvec.var[,2], pch=19)
dev.off()

lin.matrix <- data.frame(slopes=slopes, intersections=intersections, observation.slope=linmod$coefficients[2], observation.intersection=linmod$coefficients[1])
outlinfile <- paste("comus_Microsat.", mutation.param, ".slopeIntersection.txt", sep="")
write.table(x=lin.matrix, file=outlinfile, quote=F, col.names=T, row.names=F)


title <- getwd()

outlinfilepdf <- paste("comus_Microsat.", mutation.param, ".slopeIntersection.pdf", sep="")
pdf(outlinfilepdf, width=7, height=14)
layout(matrix(c(1:2), byrow=TRUE, ncol=1))
minx1 <- min(lin.matrix[,1], lin.matrix[1,3], na.rm=TRUE)
maxx1 <- max(lin.matrix[,1], lin.matrix[1,3], na.rm=TRUE)
minx2 <- min(lin.matrix[,2], lin.matrix[1,4], na.rm=TRUE)
maxx2 <- max(lin.matrix[,2], lin.matrix[1,4], na.rm=TRUE)
plot(density(lin.matrix[,1], na.rm=TRUE), xlab="Slope", ylab="Density", main=title, xlim=c(minx1, maxx1), cex.main=0.7 )
abline(v=lin.matrix[1,3], col='red', lw=2)
legend("topright", legend=c("Neutral Distribution", "Observation"), col=c("black", "red"),lw=2)
plot(density(lin.matrix[,2], na.rm=TRUE), xlab="Intersection", ylab="Density", main=title, xlim=c(minx2, maxx2), cex.main=0.7 )
abline(v=lin.matrix[1,4], col='red', lw=2)
legend("topright", legend=c("Neutral Distribution", "Observation"), col=c("black", "red"),lw=2)
dev.off()


## plot(owsvec.mean[,2], owsvec.var[,2], pch=19, xlim=c(0, 20), ylim=c(0, 20))
## points(unlist(ws.mean), unlist(ws.var), pch=1, col="red", cex=0.3)
## for(i in 3:5){
##     points(unlist(ws.mean[[i]]), unlist(ws.var[[i]]), pch=16, col=i, cex=0.9)
## }
## points(owsvec.mean[,2], owsvec.var[,2], pch=19)
## dev.off()
